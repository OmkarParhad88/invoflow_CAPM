sap.ui.define(["sap/ui/core/mvc/Controller"],function(n){"use strict";const o=n.extend("bookshop1.controller.App",{onInit:function n(){}});return o});
//# sourceMappingURL=App.controller.js.map