sap.ui.define(["sap/ui/core/mvc/Controller"], function (Controller) {
  "use strict";

  /**
   * @namespace bookshop1.controller
   */
  const App = Controller.extend("bookshop1.controller.App", {
    /*eslint-disable @typescript-eslint/no-empty-function*/onInit: function _onInit() {}
  });
  return App;
});
//# sourceMappingURL=App-dbg.controller.js.map
