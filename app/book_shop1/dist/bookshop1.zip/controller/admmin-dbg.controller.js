sap.ui.define(["sap/ui/core/mvc/Controller"], function (Controller) {
  "use strict";

  /**
   * @namespace bookshop1.controller
   */
  const admmin = Controller.extend("bookshop1.controller.admmin", {
    /*eslint-disable @typescript-eslint/no-empty-function*/onInit: function _onInit() {}
  });
  return admmin;
});
//# sourceMappingURL=admmin-dbg.controller.js.map
