sap.ui.define(["sap/ui/core/mvc/Controller"],function(n){"use strict";const o=n.extend("bookshop1.controller.admmin",{onInit:function n(){}});return o});
//# sourceMappingURL=admmin.controller.js.map